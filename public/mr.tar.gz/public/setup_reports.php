<?php
/**
 * Setup script - Updates routes and sidebar for Mark Reports
 * Run via browser after extracting the archive
 */
$base = dirname(__DIR__);
$results = [];

// 1. Update routes
$rPath = $base.'/routes/web.php';
$rContent = file_get_contents($rPath);
if (strpos($rContent, 'mark-reports') === false) {
    $insert = "

    // Mark Reports
    Route::get('mark-reports/roster', [MarkReportController::class, 'roster'])->name('mark-reports.roster');
    Route::get('mark-reports/marksheet', [MarkReportController::class, 'marksheet'])->name('mark-reports.marksheet');
    Route::get('mark-reports/report-card', [MarkReportController::class, 'reportCard'])->name('mark-reports.report-card');
    Route::get('mark-reports/student-id', [MarkReportController::class, 'studentId'])->name('mark-reports.student-id');
    Route::get('mark-reports/api/roster', [MarkReportController::class, 'apiRosterData']);
    Route::get('mark-reports/api/marksheet', [MarkReportController::class, 'apiMarksheetData']);
    Route::get('mark-reports/api/report-card', [MarkReportController::class, 'apiReportCardData']);
    Route::get('mark-reports/api/student-id', [MarkReportController::class, 'apiStudentIdData']);
    Route::get('mark-reports/export/roster-csv', [MarkReportController::class, 'exportRosterCsv']);
    Route::get('mark-reports/export/roster-pdf', [MarkReportController::class, 'exportRosterPdf']);
    Route::get('mark-reports/export/marksheet-csv', [MarkReportController::class, 'exportMarksheetCsv']);
    Route::get('mark-reports/export/marksheet-pdf', [MarkReportController::class, 'exportMarksheetPdf']);
    Route::get('mark-reports/export/report-card-pdf', [MarkReportController::class, 'exportReportCardPdf']);
    Route::get('mark-reports/export/student-id-pdf', [MarkReportController::class, 'exportStudentIdPdf']);";
    $rContent = str_replace(
        "Route::post('mark-entries/api/save'",
        $insert . "\n    Route::post('mark-entries/api/save'",
        $rContent
    );
    if (strpos($rContent, 'MarkReportController') === false) {
        $rContent = str_replace(
            'use App\Http\Controllers\Admin\MarkEntryController;',
            "use App\Http\Controllers\Admin\MarkEntryController;\nuse App\Http\Controllers\Admin\MarkReportController;",
            $rContent
        );
    }
    file_put_contents($rPath, $rContent);
    $results[] = 'Routes updated';
} else {
    $results[] = 'Routes already updated';
}

// 2. Update sidebar
$sPath = $base.'/resources/views/layouts/admin.blade.php';
$sContent = file_get_contents($sPath);
if (strpos($sContent, 'mark-reports') === false) {
    $menu = '
                        <li><a href="{{ route(\'admin.mark-reports.roster\') }}"><i class="bi bi-table"></i>
                                Mark Roster</a></li>
                        <li><a href="{{ route(\'admin.mark-reports.marksheet\') }}"><i class="bi bi-journal-text"></i>
                                Mark Sheet</a></li>
                        <li><a href="{{ route(\'admin.mark-reports.report-card\') }}"><i class="bi bi-file-earmark-person"></i>
                                Report Card</a></li>
                        <li><a href="{{ route(\'admin.mark-reports.student-id\') }}"><i class="bi bi-card-text"></i>
                                Student ID</a></li>';
    $sContent = str_replace(
        "<li><a href=\"{{ route('admin.mark-entries.index') }}\"><i class=\"bi bi-pencil-square\"></i> Mark\n                                Entry</a></li>",
        "<li><a href=\"{{ route('admin.mark-entries.index') }}\"><i class=\"bi bi-pencil-square\"></i> Mark\n                                Entry</a></li>" . $menu,
        $sContent
    );
    file_put_contents($sPath, $sContent);
    $results[] = 'Sidebar updated';
} else {
    $results[] = 'Sidebar already updated';
}

echo '<div style="font-family:Arial;max-width:500px;margin:40px auto;padding:20px;">';
echo '<h2 style="color:#28a745;">Setup Complete!</h2>';
echo '<ul>';
foreach ($results as $r) echo "<li style='color:green;'>$r</li>";
echo '</ul>';
echo '<hr>';
echo '<p><strong>Now run in Git Bash:</strong></p>';
echo '<pre>cd /c/xampp/htdocs/school-of-redemption && php artisan view:clear && php artisan cache:clear</pre>';
echo '<p><strong>Then DELETE this file:</strong></p>';
echo '<pre>rm public/setup_reports.php</pre>';
echo '<p><a href="/school-of-redemption/public/admin/mark-reports/roster" style="display:inline-block;background:#28a745;color:#fff;padding:10px 20px;border-radius:5px;text-decoration:none;font-weight:bold;">Go to Mark Roster &rarr;</a></p>';
echo '</div>';
