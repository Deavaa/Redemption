@extends('layouts.admin')
@section('content')
<div class="container-fluid py-4">
    <div class="card shadow-sm">
        <div class="card-header bg-success bg-gradient text-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="bi bi-journal-text me-2"></i>Mark Sheet</h5>
            <div class="d-flex gap-2">
                <button id="btnCSV" class="btn btn-sm btn-light" onclick="exportCSV()" disabled><i class="bi bi-file-earmark-spreadsheet"></i> CSV</button>
                <button id="btnPDF" class="btn btn-sm btn-light" onclick="exportPDF()" disabled><i class="bi bi-file-earmark-pdf"></i> PDF</button>
                <button id="btnPrint" class="btn btn-sm btn-light" onclick="window.print()" disabled><i class="bi bi-printer"></i> Print</button>
            </div>
        </div>
        <div class="card-body">
            <div class="row g-2 mb-3 p-2 bg-light rounded">
                <div class="col-md-3bg-light rounded">
    <label class="form-label fw-bold small">Academic Year</labelg-light rounded">
    <select id="filterAy" class="form-select form-select-sm" onchange="loadTerms()">
                        <option value="">-- Select --</option>
                        @foreach($academicYears as $ay)
                        <option value="{{ $ay->id }}">{{ $ay->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-3bg-light rounded">
    <label class="form-label fw-bold small">Term</labelg-light rounded">
    <select id="filterTerm" class="form-select form-select-sm">
                        <option value="">-- Select --</option>
                    </select>
                </div>
                <div class="col-md-3bg-light rounded">
    <label class="form-label fw-bold small">Class</labelg-light rounded">
    <select id="filterClass" class="form-select form-select-sm" onchange="loadSections()">
                        <option value="">-- Select --</option>
                        @foreach($classrooms as $c)
                        <option value="{{ $c->id }}">{{ $c->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-3bg-light rounded">
    <label class="form-label fw-bold small">Section</labelg-light rounded">
    <select id="filterSection" class="form-select form-select-sm">
                        <option value="">-- Select --</option>
                    </select>
                </div>
            </div>
            <div class="row mb-2">
                <div class="col-md-4 d-flex align-items-endbg-light rounded">
    <button class="btn btn-success btn-sm w-100" onclick="loadSheet()"><i class="bi bi-search"></i> Load Mark Sheet</button>
                </div>
            </div>
            <div id="sheetInfo" class="mb-2 fw-bold text-success" style="display:none;"></div>
            <div id="sheetContainer" class="table-responsive" style="display:none;">
                <table class="table table-bordered table-sm table-hover" id="sheetTable">
                    <thead class="table-dark">
                        <tr id="sheetHeader1"></tr>
                        <tr id="sheetHeader2"></tr>
                    </thead>
                    <tbody id="sheetBody"></tbody>
                    <tfoot class="table-info">
                        <tr id="sheetAvg"></tr>
                    </tfoot>
                </table>
            </div>
            <div id="emptyState" class="text-center text-muted py-5" style="display:none;">
                <i class="bi bi-journal fs-1"></i>
                <p class="mt-2">Select filters and click Load to view the mark sheet.</p>
            </div>
        </div>
    </div>
</div>
<style>
.subj-header { background: rgba(13,110,253,0.15) !important; text-align:center; font-size:0.75rem; font-weight:700; letter-spacing:0.5px; }
.td-center { text-align:center; font-size:0.85rem; }
.grade-a-plus { background:#d4edda !important; color:#155724 !important; font-weight:700; }
.grade-a { background:#d1ecf1 !important; color:#0c5460 !important; font-weight:700; }
.grade-b { background:#fff3cd !important; color:#856404 !important; font-weight:600; }
.grade-c { background:#ffeeba !important; color:#856404 !important; }
.grade-d { background:#f5c6cb !important; color:#721c24 !important; }
.grade-f { background:#f8d7da !important; color:#721c24 !important; font-weight:700; }
@media print {
    .card-header .btn, .card-body .row { display:none !important; }
    .card { border:none !important; box-shadow:none !important; }
}
</style>
<script>
const API = '{{ request()->root() }}/admin/mark-reports/api';
let sheetData = null;

function loadTerms() {
    const ayId = document.getElementById('filterAy').value;
    fetch(`${API}/../terms?academic_year_id=${ayId}`).then(r=>r.json()).then(data=>{
        const sel = document.getElementById('filterTerm');
        sel.innerHTML = '<option value="">-- Select --</option>';
        (data.terms||data||[]).forEach(t=>{ sel.innerHTML += `<option value="${t.id}">${t.name}</option>`; });
    });
}
function loadSections() {
    const cId = document.getElementById('filterClass').value;
    fetch(`${API}/../sections?class_id=${cId}`).then(r=>r.json()).then(data=>{
        const sel = document.getElementById('filterSection');
        sel.innerHTML = '<option value="">-- Select --</option>';
        (data.sections||data||[]).forEach(s=>{ sel.innerHTML += `<option value="${s.id}">${s.name}</option>`; });
    });
}
function loadSheet() {
    const ayId = document.getElementById('filterAy').value;
    const termId = document.getElementById('filterTerm').value;
    const classId = document.getElementById('filterClass').value;
    const sectionId = document.getElementById('filterSection').value;
    if (!ayId||!termId||!classId||!sectionId) { alert('Please select all filters'); return; }

    document.getElementById('sheetContainer').style.display='none';
    document.getElementById('emptyState').style.display='block';

    fetch(`${API}/marksheet?academic_year_id=${ayId}&term_id=${termId}&class_id=${classId}&section_id=${sectionId}`)
    .then(r=>{ if(!r.ok) throw new Error('HTTP '+r.status); return r.json(); })
    .then(data=>{
        if (data.error) { alert(data.error); return; }
        sheetData = data;
        renderSheet(data);
        document.getElementById('btnCSV').disabled = false;
        document.getElementById('btnPDF').disabled = false;
        document.getElementById('btnPrint').disabled = false;
    }).catch(err=>{ alert('Error: '+err.message); });
}

function gradeClass(g) {
    if (!g) return '';
    g = g.trim();
    if (g==='A+') return 'grade-a-plus';
    if (g==='A') return 'grade-a';
    if (g.startsWith('B')) return 'grade-b';
    if (g==='C') return 'grade-c';
    if (g==='D') return 'grade-d';
    return 'grade-f';
}

function renderSheet(data) {
    document.getElementById('emptyState').style.display='none';
    document.getElementById('sheetContainer').style.display='block';
    document.getElementById('sheetInfo').style.display='block';
    document.getElementById('sheetInfo').textContent = `${data.school_name} | ${data.class} - ${data.section} | ${data.term} | ${data.students.length} Students`;

    const h1 = document.getElementById('sheetHeader1');
    const h2 = document.getElementById('sheetHeader2');
    const body = document.getElementById('sheetBody');

    let h1HTML = '<th rowspan="2" class="text-center" style="min-width:30px;">#</th><th rowspan="2" class="text-center" style="min-width:50px;">Roll</th><th rowspan="2" style="min-width:180px;">Student Name</th>';
    let h2HTML = '';
    data.subjects.forEach(s=>{
        h1HTML += `<th colspan="4" class="subj-header">${s.name}</th>`;
        h2HTML += '<th class="text-center" style="font-size:0.7rem;">CA</th><th class="text-center" style="font-size:0.7rem;">Exam</th><th class="text-center" style="font-size:0.7rem;">Total</th><th class="text-center" style="font-size:0.7rem;">Grade</th>';
    });
    h1HTML += '<th colspan="2" class="subj-header" style="background:rgba(40,167,69,0.3) !important;">Overall</th>';
    h2HTML += '<th class="text-center" style="font-size:0.7rem;">Grand Total</th><th class="text-center" style="font-size:0.7rem;">Position</th>';
    h1.innerHTML = h1HTML;
    h2.innerHTML = h2HTML;

    let bHTML = '';
    data.students.forEach((s,i)=>{
        bHTML += `<tr><td class="text-center">${i+1}</td><td class="text-center">${s.roll_number||''}</td><td class="fw-bold">${s.student_name}</td>`;
        let totalG = 0;
        data.subjects.forEach(subj=>{
            const sub = s.subjects[subj.id] || {ca_total:0,exam_total:0,grand_total:0,grade:'-'};
            totalG += sub.grand_total;
            bHTML += `<td class="td-center">${sub.ca_total}</td><td class="td-center">${sub.exam_total}</td><td class="td-center fw-bold">${sub.grand_total}</td><td class="td-center ${gradeClass(sub.grade)}">${sub.grade}</td>`;
        });
        bHTML += `<td class="td-center fw-bold bg-success text-white">${s.total_grand}</td><td class="td-center fw-bold">${s.position}</td></tr>`;
    });
    body.innerHTML = bHTML;
}

function exportCSV() {
    if (!sheetData) return;
    const p = new URLSearchParams({academic_year_id:document.getElementById('filterAy').value,term_id:document.getElementById('filterTerm').value,class_id:document.getElementById('filterClass').value,section_id:document.getElementById('filterSection').value});
    window.location.href = `${API}/../export/marksheet-csv?${p}`;
}
function exportPDF() {
    if (!sheetData) return;
    const p = new URLSearchParams({academic_year_id:document.getElementById('filterAy').value,term_id:document.getElementById('filterTerm').value,class_id:document.getElementById('filterClass').value,section_id:document.getElementById('filterSection').value});
    window.location.href = `${API}/../export/marksheet-pdf?${p}`;
}
</script>
@endsection
