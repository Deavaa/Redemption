<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Mark Roster</title>
<style>
body { font-family: Arial, sans-serif; font-size: 10px; margin: 20px; }
h3 { text-align: center; margin: 0 0 5px; }
.info { text-align: center; margin-bottom: 10px; font-size: 11px; color: #555; }
table { width: 100%; border-collapse: collapse; font-size: 9px; }
th, td { border: 1px solid #333; padding: 3px 4px; text-align: center; }
th { background: #1a365d; color: white; font-weight: bold; }
.rotate { writing-mode: vertical-rl; transform: rotate(180deg); height: 80px; white-space: nowrap; font-size: 8px; }
.name-col { text-align: left; min-width: 130px; }
.total-col { background: #e8f5e9; font-weight: bold; }
.avg-row { background: #fff3e0; font-weight: bold; }
</style>
</head>
<body>
<h3>{{ $school_name }}</h3>
<div class="info">
    <strong>Mark Roster</strong> | {{ $class }} - {{ $section }} | {{ $subject }} | {{ $term }}
</div>
<table>
<thead>
<tr>
    <th rowspan="2" style="width:25px;">#</th>
    <th rowspan="2" style="width:40px;">Roll</th>
    <th rowspan="2" class="name-col">Student Name</th>
    @foreach($markFields as $f)
    @if(in_array($f['col'], ['test1','test2','mid_term','final_exam']))
    <th class="rotate" style="background:rgba(255,193,7,0.3);">{{ strtoupper(str_replace('_',' ',$f['col'])) }}<br>({{ $f['max'] }})</th>
    @else
    <th class="rotate">{{ strtoupper(str_replace('_',' ',$f['col'])) }}<br>({{ $f['max'] }})</th>
    @endif
    @endforeach
    <th class="rotate" style="background:#4caf50;">CA TOTAL</th>
    <th class="rotate" style="background:#4caf50;">EXAM TOTAL</th>
    <th class="rotate" style="background:#2e7d32;">GRAND</th>
</tr>
</thead>
<tbody>
@foreach($students as $i => $s)
<tr>
    <td>{{ $i + 1 }}</td>
    <td>{{ $s['roll_number'] }}</td>
    <td class="name-col" style="text-align:left;">{{ $s['student_name'] }}</td>
    @foreach($markFields as $f)
    <td>{{ $s[$f['col']] !== null ? $s[$f['col']] : '-' }}</td>
    @endforeach
    <td class="total-col">{{ $s['ca_total'] }}</td>
    <td class="total-col">{{ $s['exam_total'] }}</td>
    <td class="total-col" style="background:#4caf50;color:white;">{{ $s['grand_total'] }}</td>
</tr>
@endforeach
</tbody>
</table>
<div style="margin-top:15px; font-size:9px; color:#888;">
    Generated on: {{ date('Y-m-d H:i') }} | {{ $school_name }}
</div>
</body>
</html>
