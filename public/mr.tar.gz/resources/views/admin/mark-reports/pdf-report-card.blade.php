<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Report Card</title>
<style>
body { font-family: Arial, sans-serif; font-size: 11px; margin: 30px; }
.report { max-width: 700px; margin: 0 auto; border: 2px solid #1a365d; padding: 25px; }
.header { text-align: center; border-bottom: 2px solid #1a365d; padding-bottom: 10px; margin-bottom: 15px; }
.header h2 { margin: 0; color: #1a365d; }
.header .details { color: #555; font-size: 10px; }
.header .motto { font-style: italic; font-size: 9px; color: #888; }
.student-info { display: flex; justify-content: space-between; margin-bottom: 12px; }
.info-table { font-size: 11px; }
.info-table td { padding: 2px 8px; vertical-align: top; }
.info-table .label { font-weight: bold; width: 120px; color: #333; }
.photo { width: 90px; height: 110px; border: 2px solid #1a365d; border-radius: 6px; overflow: hidden; background: #f5f5f5; text-align: center; }
.photo img { width: 100%; height: 100%; object-fit: cover; }
.academic-bar { display: flex; justify-content: space-between; margin-bottom: 12px; padding: 5px 10px; background: #f0f4f8; border-radius: 4px; font-size: 10px; }
table.marks { width: 100%; border-collapse: collapse; font-size: 10px; margin-bottom: 12px; }
table.marks th, table.marks td { border: 1px solid #ccc; padding: 4px 6px; text-align: center; }
table.marks th { background: #1a365d; color: white; font-size: 9px; }
table.marks td.subj-name { text-align: left; }
table.marks .total-row td { background: #e8f5e9; font-weight: bold; }
.g-a-plus { background: #c8e6c9 !important; font-weight: bold; }
.g-a { background: #b2ebf2 !important; font-weight: bold; }
.g-b { background: #fff9c4 !important; }
.g-c { background: #ffe0b2 !important; }
.g-d { background: #ffcdd2 !important; }
.g-f { background: #ef9a9a !important; font-weight: bold; }
.grade-scale { text-align: center; font-size: 9px; margin-bottom: 12px; padding: 5px; border: 1px dashed #ccc; }
.comments { display: flex; gap: 10px; margin-bottom: 15px; }
.comment-box { flex: 1; border: 1px solid #ccc; border-radius: 4px; padding: 8px; min-height: 50px; }
.comment-box .title { font-weight: bold; font-size: 9px; color: #333; margin-bottom: 4px; }
.comment-box .text { font-size: 10px; }
.signatures { display: flex; justify-content: space-around; margin-top: 20px; }
.sig { text-align: center; width: 150px; }
.sig .line { border-top: 1px solid #333; margin-top: 40px; padding-top: 4px; font-size: 9px; }
</style>
</head>
<body>
<div class="report">
    <div class="header">
        <h2>{{ $school_name }}</h2>
        <div class="details">{{ $school_address }}{{ $school_phone ? ' | '.$school_phone : '' }}{{ $school_email ? ' | '.$school_email : '' }}</div>
        @if($school_motto)<div class="motto">{{ $school_motto }}</div>@endif
        <div style="font-size:13px;font-weight:bold;margin-top:5px;">STUDENT REPORT CARD</div>
    </div>

    <div class="student-info">
        <table class="info-table">
            <tr><td class="label">Student Name:</td><td>{{ $student['name'] }}</td></tr>
            <tr><td class="label">Roll Number:</td><td>{{ $student['roll_number'] ?? '-' }}</td></tr>
            <tr><td class="label">Admission No:</td><td>{{ $student['admission_number'] ?? '-' }}</td></tr>
            <tr><td class="label">Class & Section:</td><td>{{ $student['class_name'] }} - {{ $student['section_name'] }}</td></tr>
        </table>
        <div class="photo">
            @if($student['photo'])
            <img src="{{ $student['photo'] }}" onerror="this.style.display='none'">
            @endif
        </div>
    </div>

    <div class="academic-bar">
        <div><strong>Academic Year:</strong> {{ $academic_year }}</div>
        <div><strong>Term:</strong> {{ $term }}</div>
        <div><strong>Position:</strong> {{ $position }} / {{ $total_students }}</div>
    </div>

    <table class="marks">
        <thead>
            <tr>
                <th style="width:25px;">#</th>
                <th style="text-align:left;">Subject</th>
                <th style="width:65px;">CA (30%)</th>
                <th style="width:65px;">Exam (70%)</th>
                <th style="width:65px;">Total (100)</th>
                <th style="width:50px;">Grade</th>
                <th style="width:80px;">Remarks</th>
            </tr>
        </thead>
        <tbody>
            @php $tCA=0; $tEX=0; @endphp
            @foreach($subjects as $i => $s)
            @php $tCA += $s['ca_total']; $tEX += $s['exam_total']; @endphp
            <tr>
                <td>{{ $i + 1 }}</td>
                <td class="subj-name">{{ $s['name'] }}</td>
                <td>{{ number_format($s['ca_total'],1) }}</td>
                <td>{{ number_format($s['exam_total'],1) }}</td>
                <td style="font-weight:bold;">{{ $s['grand_total'] }}</td>
                <td class="{{ ($s['grade']==='A+'?'g-a-plus':($s['grade']==='A'?'g-a':($s['grade'][0]==='B'?'g-b':($s['grade']==='C'?'g-c':($s['grade']==='D'?'g-d':'g-f'))))) }}">{{ $s['grade'] }}</td>
                <td style="font-size:9px;">{{ $s['grade']==='A+'||$s['grade']==='A' ? 'Excellent' : ($s['grade'][0]==='B' ? 'Good' : ($s['grade']==='C' ? 'Satisfactory' : ($s['grade']==='D' ? 'Needs Improvement' : 'Fail'))) }}</td>
            </tr>
            @endforeach
        </tbody>
        <tfoot>
            <tr class="total-row">
                <td colspan="2" style="text-align:right;font-weight:bold;">TOTAL</td>
                <td>{{ number_format($tCA,1) }}</td>
                <td>{{ number_format($tEX,1) }}</td>
                <td>{{ number_format($grand_total,1) }}</td>
                <td class="{{ ($overall_grade==='A+'?'g-a-plus':($overall_grade==='A'?'g-a':($overall_grade[0]==='B'?'g-b':($overall_grade==='C'?'g-c':($overall_grade==='D'?'g-d':'g-f'))))) }}">{{ $overall_grade }}</td>
                <td></td>
            </tr>
        </tfoot>
    </table>

    <div class="grade-scale">
        <strong>Grading Scale:</strong> A+ (90-100) | A (80-89) | B+ (70-79) | B (60-69) | C (50-59) | D (40-49) | F (0-39)
    </div>

    <div class="comments">
        <div class="comment-box">
            <div class="title">Teacher's Comment:</div>
            <div class="text">{{ $student['teacher_comments'] ?: 'No comment' }}</div>
        </div>
        <div class="comment-box">
            <div class="title">Admin Comment:</div>
            <div class="text">{{ $student['admin_comments'] ?: 'No comment' }}</div>
        </div>
    </div>

    <div class="signatures">
        <div class="sig"><div class="line">Class Teacher<br><small>Date: ________</small></div></div>
        <div class="sig"><div class="line">Headmaster / Principal<br><small>Date: ________</small></div></div>
        <div class="sig"><div class="line">Parent / Guardian<br><small>Date: ________</small></div></div>
    </div>
</div>
</body>
</html>
