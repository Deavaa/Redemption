<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\MarkEntry;
use App\Models\Student;
use App\Models\Subject;
use App\Models\Term;
use App\Models\AcademicYear;
use App\Models\ClassRoom;
use App\Models\Section;
use App\Models\Setting;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\DB;

class MarkReportController extends Controller
{
    public function roster() {
        $academicYears = AcademicYear::orderBy('name','desc')->get();
        $classrooms = ClassRoom::orderBy('name')->get();
        return view('admin.mark-reports.roster', compact('academicYears','classrooms'));
    }

    public function apiRosterData(Request $request) {
        $ayId = $request->query('academic_year_id');
        $termId = $request->query('term_id');
        $classId = $request->query('class_id');
        $sectionId = $request->query('section_id');
        $subjectId = $request->query('subject_id');
        if (!$ayId||!$termId||!$classId||!$sectionId||!$subjectId) return response()->json(['error'=>'All filters required'],400);

        $students = DB::table('students')
            ->where('status','active')->where('class_id',$classId)
            ->where('section_id',$sectionId)->where('academic_year_id',$ayId)
            ->orderBy('roll_number')->orderBy('first_name')
            ->select('id','first_name','last_name','roll_number')->get();

        $markFields = MarkEntry::getMarkFields();
        $studentIds = $students->pluck('id')->toArray();
        $marks = MarkEntry::whereIn('student_id',$studentIds)
            ->where('subject_id',$subjectId)->where('term_id',$termId)
            ->where('academic_year_id',$ayId)->where('class_id',$classId)
            ->where('section_id',$sectionId)->get()->keyBy('student_id');

        $rows = [];
        foreach ($students as $s) {
            $name = trim(($s->first_name??'').' '.($s->last_name??''));
            $mark = $marks->get($s->id);
            $row = ['id'=>$s->id,'roll_number'=>$s->roll_number,'student_name'=>$name?:'Unknown'];
            foreach ($markFields as $field) { $row[$field['col']] = $mark ? floatval($mark->{$field['col']}) : null; }
            $row['ca_total'] = $mark ? floatval($mark->ca_total) : 0;
            $row['exam_total'] = $mark ? floatval($mark->exam_total) : 0;
            $row['grand_total'] = $mark ? floatval($mark->grand_total) : 0;
            $rows[] = $row;
        }

        $subject = Subject::find($subjectId);
        $term = Term::find($termId);
        $class = ClassRoom::find($classId);
        $section = Section::find($sectionId);

        return response()->json([
            'students'=>$rows,'markFields'=>$markFields,
            'subject'=>$subject?$subject->name:'',
            'term'=>$term?$term->name:'',
            'class'=>$class?$class->name:'',
            'section'=>$section?$section->name:'',
            'school_name'=>Setting::get('school_name','School of Redemption'),
        ]);
    }

    public function marksheet() {
        $academicYears = AcademicYear::orderBy('name','desc')->get();
        $classrooms = ClassRoom::orderBy('name')->get();
        return view('admin.mark-reports.marksheet', compact('academicYears','classrooms'));
    }

    public function apiMarksheetData(Request $request) {
        $ayId = $request->query('academic_year_id');
        $termId = $request->query('term_id');
        $classId = $request->query('class_id');
        $sectionId = $request->query('section_id');
        if (!$ayId||!$termId||!$classId||!$sectionId) return response()->json(['error'=>'All filters required'],400);

        $students = DB::table('students')
            ->where('status','active')->where('class_id',$classId)
            ->where('section_id',$sectionId)->where('academic_year_id',$ayId)
            ->orderBy('roll_number')->orderBy('first_name')
            ->select('id','first_name','last_name','roll_number')->get();

        $subjects = Subject::orderBy('name')->get();
        $studentIds = $students->pluck('id')->toArray();
        $subjectIds = $subjects->pluck('id')->toArray();

        $allMarks = MarkEntry::whereIn('student_id',$studentIds)
            ->whereIn('subject_id',$subjectIds)->where('term_id',$termId)
            ->where('academic_year_id',$ayId)->where('class_id',$classId)
            ->where('section_id',$sectionId)->get();

        $marksMap = [];
        foreach ($allMarks as $m) { $marksMap[$m->student_id][$m->subject_id] = $m; }

        $rows = [];
        foreach ($students as $s) {
            $name = trim(($s->first_name??'').' '.($s->last_name??''));
            $row = ['id'=>$s->id,'roll_number'=>$s->roll_number,'student_name'=>$name?:'Unknown','subjects'=>[],'total_grand'=>0];
            foreach ($subjects as $subj) {
                $m = $marksMap[$s->id][$subj->id] ?? null;
                $caT = $m ? floatval($m->ca_total) : 0;
                $exT = $m ? floatval($m->exam_total) : 0;
                $gT = $m ? floatval($m->grand_total) : 0;
                $row['subjects'][$subj->id] = ['ca_total'=>$caT,'exam_total'=>$exT,'grand_total'=>$gT,'grade'=>$this->getGrade($gT)];
                $row['total_grand'] += $gT;
            }
            $row['avg_grade'] = $this->getGrade($subjects->count() > 0 ? $row['total_grand'] / $subjects->count() : 0);
            $rows[] = $row;
        }

        $positioned = $rows;
        usort($positioned, function($a,$b){ return $b['total_grand'] <=> $a['total_grand']; });
        $posMap = [];
        foreach ($positioned as $i=>$r) { $posMap[$r['id']] = $i+1; }
        foreach ($rows as &$row) { $row['position'] = $posMap[$row['id']]; }

        $term = Term::find($termId);
        $class = ClassRoom::find($classId);
        $section = Section::find($sectionId);

        return response()->json([
            'students'=>$rows,'subjects'=>$subjects,
            'term'=>$term?$term->name:'',
            'class'=>$class?$class->name:'',
            'section'=>$section?$section->name:'',
            'school_name'=>Setting::get('school_name','School of Redemption'),
        ]);
    }

    public function reportCard() {
        $academicYears = AcademicYear::orderBy('name','desc')->get();
        $terms = Term::orderBy('name')->get();
        $students = Student::where('status','active')->orderBy('first_name')->orderBy('last_name')->get();
        return view('admin.mark-reports.report-card', compact('academicYears','terms','students'));
    }

    public function apiReportCardData(Request $request) {
        $studentId = $request->query('student_id');
        $ayId = $request->query('academic_year_id');
        $termId = $request->query('term_id');
        if (!$studentId||!$ayId||!$termId) return response()->json(['error'=>'All filters required'],400);

        $student = Student::find($studentId);
        if (!$student) return response()->json(['error'=>'Student not found'],404);

        $name = trim(($student->first_name??'').' '.($student->last_name??''));

        $marks = MarkEntry::where('student_id',$studentId)
            ->where('academic_year_id',$ayId)->where('term_id',$termId)
            ->with('subject')->get();

        $subjects = [];
        $grandTotal = 0;
        $totalMax = 0;
        foreach ($marks as $m) {
            $gT = floatval($m->grand_total);
            $subjects[] = [
                'name'=>$m->subject?$m->subject->name:'Unknown',
                'ca_total'=>floatval($m->ca_total),
                'exam_total'=>floatval($m->exam_total),
                'grand_total'=>$gT,
                'grade'=>$this->getGrade($gT),
            ];
            $grandTotal += $gT;
            $totalMax += 100;
        }

        $class = ClassRoom::find($student->class_id);
        $section = Section::find($student->section_id);
        $term = Term::find($termId);
        $ay = AcademicYear::find($ayId);

        $allTotals = MarkEntry::where('term_id',$termId)
            ->where('academic_year_id',$ayId)
            ->where('class_id',$student->class_id)
            ->where('section_id',$student->section_id)
            ->select('student_id', DB::raw('SUM(grand_total) as total'))
            ->groupBy('student_id')->orderByDesc('total')->get();
        $position = 1;
        foreach ($allTotals as $am) { if ($am->student_id == $studentId) break; $position++; }
        $totalStudents = $allTotals->count();

        return response()->json([
            'student'=>[
                'name'=>$name,'roll_number'=>$student->roll_number,
                'admission_number'=>$student->admission_number,
                'gender'=>$student->gender,'date_of_birth'=>$student->date_of_birth,
                'class_name'=>$class?$class->name:'',
                'section_name'=>$section?$section->name:'',
                'photo'=>$student->photo,
                'teacher_comments'=>$student->teacher_comments,
                'admin_comments'=>$student->admin_comments,
                'guardian_name'=>$student->guardian_name,
            ],
            'subjects'=>$subjects,'grand_total'=>$grandTotal,
            'total_max'=>$totalMax,
            'overall_grade'=>$this->getGrade($totalMax > 0 ? ($grandTotal/$totalMax)*100 : 0),
            'position'=>$position,'total_students'=>$totalStudents,
            'term'=>$term?$term->name:'',
            'academic_year'=>$ay?$ay->name:'',
            'school_name'=>Setting::get('school_name','School of Redemption'),
            'school_address'=>Setting::get('school_address',''),
            'school_phone'=>Setting::get('school_phone',''),
            'school_email'=>Setting::get('school_email',''),
            'school_motto'=>Setting::get('school_motto',''),
            'school_logo'=>Setting::get('school_logo',''),
        ]);
    }

    public function studentId() {
        $classrooms = ClassRoom::orderBy('name')->get();
        $students = Student::where('status','active')->orderBy('first_name')->get();
        return view('admin.mark-reports.student-id', compact('classrooms','students'));
    }

    public function apiStudentIdData(Request $request) {
        $classId = $request->query('class_id');
        $sectionId = $request->query('section_id');
        $studentId = $request->query('student_id');

        $query = DB::table('students')->where('status','active');
        if ($studentId) { $query->where('id',$studentId); }
        elseif ($classId && $sectionId) { $query->where('class_id',$classId)->where('section_id',$sectionId); }
        else { return response()->json(['error'=>'Select a student or class+section'],400); }

        $students = $query->orderBy('roll_number')->orderBy('first_name')->get();
        $class = ClassRoom::find($classId);
        $section = Section::find($sectionId);
        $ay = AcademicYear::where('is_active',1)->first();

        $rows = [];
        foreach ($students as $s) {
            $cId = $s->class_id ?: $classId;
            $sId = $s->section_id ?: $sectionId;
            $cl = ClassRoom::find($cId);
            $sec = Section::find($sId);
            $rows[] = [
                'id'=>$s->id,
                'name'=>trim(($s->first_name??'').' '.($s->last_name??'')),
                'roll_number'=>$s->roll_number,
                'admission_number'=>$s->admission_number,
                'gender'=>$s->gender,
                'date_of_birth'=>$s->date_of_birth,
                'class_name'=>$cl?$cl->name:'',
                'section_name'=>$sec?$sec->name:'',
                'photo'=>$s->photo,
                'guardian_name'=>$s->guardian_name,
                'guardian_phone'=>$s->guardian_phone,
                'address'=>$s->address,
            ];
        }

        return response()->json([
            'students'=>$rows,
            'academic_year'=>$ay?$ay->name:date('Y').' / '.(date('Y')+1),
            'school_name'=>Setting::get('school_name','School of Redemption'),
            'school_address'=>Setting::get('school_address',''),
            'school_phone'=>Setting::get('school_phone',''),
            'school_email'=>Setting::get('school_email',''),
            'school_logo'=>Setting::get('school_logo',''),
        ]);
    }

    // CSV Exports
    public function exportRosterCsv(Request $request) {
        $response = $this->apiRosterData($request);
        $data = json_decode($response->content(), true);
        if (isset($data['error'])) return redirect()->back()->with('error',$data['error']);

        $headers = ['No','Roll No','Student Name'];
        foreach ($data['markFields'] as $f) { $headers[] = strtoupper(str_replace('_',' ',$f['col'])).' ('.$f['max'].')'; }
        $headers[] = 'CA Total'; $headers[] = 'Exam Total'; $headers[] = 'Grand Total';

        $csv = implode(',',$headers)."\n";
        foreach ($data['students'] as $i=>$s) {
            $row = [$i+1, $s['roll_number'], '"'.$s['student_name'].'"'];
            foreach ($data['markFields'] as $f) { $row[] = $s[$f['col']] ?? ''; }
            $row[] = $s['ca_total']; $row[] = $s['exam_total']; $row[] = $s['grand_total'];
            $csv .= implode(',',$row)."\n";
        }

        $filename = 'mark_roster_'.$data['subject'].'_'.$data['term'].'.csv';
        return response($csv)->header('Content-Type','text/csv')->header('Content-Disposition','attachment; filename="'.$filename.'"');
    }

    public function exportMarksheetCsv(Request $request) {
        $response = $this->apiMarksheetData($request);
        $data = json_decode($response->content(), true);
        if (isset($data['error'])) return redirect()->back()->with('error',$data['error']);

        $headers = ['No','Roll No','Student Name'];
        foreach ($data['subjects'] as $subj) {
            $headers[] = $subj->name.' CA';
            $headers[] = $subj->name.' Exam';
            $headers[] = $subj->name.' Total';
        }
        $headers[] = 'Grand Total'; $headers[] = 'Position';

        $csv = implode(',',$headers)."\n";
        foreach ($data['students'] as $i=>$s) {
            $row = [$i+1, $s['roll_number'], '"'.$s['student_name'].'"'];
            foreach ($data['subjects'] as $subj) {
                $sub = $s['subjects'][$subj->id] ?? ['ca_total'=>0,'exam_total'=>0,'grand_total'=>0];
                $row[] = $sub['ca_total']; $row[] = $sub['exam_total']; $row[] = $sub['grand_total'];
            }
            $row[] = $s['total_grand']; $row[] = $s['position'];
            $csv .= implode(',',$row)."\n";
        }

        $filename = 'mark_sheet_'.$data['class'].'_'.$data['term'].'.csv';
        return response($csv)->header('Content-Type','text/csv')->header('Content-Disposition','attachment; filename="'.$filename.'"');
    }

    // PDF Exports
    public function exportRosterPdf(Request $request) {
        $response = $this->apiRosterData($request);
        $data = json_decode($response->content(), true);
        if (isset($data['error'])) return redirect()->back()->with('error',$data['error']);

        $pdf = Pdf::loadView('admin.mark-reports.pdf-roster', $data)->setPaper('a4','landscape');
        return $pdf->download('mark_roster_'.$data['subject'].'_'.$data['term'].'.pdf');
    }

    public function exportMarksheetPdf(Request $request) {
        $response = $this->apiMarksheetData($request);
        $data = json_decode($response->content(), true);
        if (isset($data['error'])) return redirect()->back()->with('error',$data['error']);

        $pdf = Pdf::loadView('admin.mark-reports.pdf-marksheet', $data)->setPaper('a4','landscape');
        return $pdf->download('mark_sheet_'.$data['class'].'_'.$data['term'].'.pdf');
    }

    public function exportReportCardPdf(Request $request) {
        $response = $this->apiReportCardData($request);
        $data = json_decode($response->content(), true);
        if (isset($data['error'])) return redirect()->back()->with('error',$data['error']);

        $pdf = Pdf::loadView('admin.mark-reports.pdf-report-card', $data)->setPaper('a4','portrait');
        return $pdf->download('report_card_'.$data['student']['name'].'_'.$data['term'].'.pdf');
    }

    public function exportStudentIdPdf(Request $request) {
        $response = $this->apiStudentIdData($request);
        $data = json_decode($response->content(), true);
        if (isset($data['error'])) return redirect()->back()->with('error',$data['error']);

        $pdf = Pdf::loadView('admin.mark-reports.pdf-student-id', $data)->setPaper('a4','portrait');
        return $pdf->download('student_ids.pdf');
    }

    private function getGrade($total) {
        if ($total >= 90) return 'A+';
        if ($total >= 80) return 'A';
        if ($total >= 70) return 'B+';
        if ($total >= 60) return 'B';
        if ($total >= 50) return 'C';
        if ($total >= 40) return 'D';
        return 'F';
    }
}
